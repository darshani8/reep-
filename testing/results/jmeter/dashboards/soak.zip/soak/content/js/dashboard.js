/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /api/auth/me"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/ledger"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/placement-readiness"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/auth/login"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/leaderboards"], "isController": false}, {"data": [1.0, 500, 1500, "GET /health"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/auth/sso/status"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/timesheet"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/badges"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/profile"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/programme"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/dashboard"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/register/hierarchy"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 13533, 0, 0.0, 7.86514446168629, 1, 180, 7.0, 12.0, 16.0, 35.0, 22.626726723714174, 79.69946697175881, 11.419369975739762], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /api/auth/me", 1167, 0, 0.0, 10.199657240788351, 6, 61, 8.0, 14.0, 19.0, 41.0, 1.9610446133448496, 3.811354127456977, 1.084130410306995], "isController": false}, {"data": ["GET /api/student/ledger", 1152, 0, 0.0, 7.091145833333334, 4, 76, 6.0, 9.0, 13.0, 23.0, 1.9570236252843374, 7.625511977426276, 1.0952847643502326], "isController": false}, {"data": ["GET /api/student/jobs", 1161, 0, 0.0, 11.905254091300591, 7, 72, 10.0, 17.0, 21.0, 35.0, 1.9640084041289851, 2.347603795560427, 1.0953581270363264], "isController": false}, {"data": ["GET /api/student/placement-readiness", 1145, 0, 0.0, 10.229694323144104, 6, 69, 9.0, 14.0, 18.0, 40.539999999999964, 1.9620779176269996, 2.7170180539014503, 1.1230238651649773], "isController": false}, {"data": ["POST /api/auth/login", 30, 0, 0.0, 60.2, 39, 180, 44.0, 140.40000000000006, 177.8, 180.0, 1.0320627494151644, 0.9767304789631209, 0.2600314349112426], "isController": false}, {"data": ["GET /api/student/leaderboards", 1158, 0, 0.0, 7.516407599309149, 4, 88, 6.0, 10.0, 15.0, 31.410000000000082, 1.963041256075172, 0.7457256334113691, 1.1101554937820075], "isController": false}, {"data": ["GET /health", 652, 0, 0.0, 2.4217791411042944, 1, 53, 2.0, 3.0, 5.0, 23.940000000000055, 1.0901223545305285, 0.30020947654063385, 0.17671905356647238], "isController": false}, {"data": ["GET /api/auth/sso/status", 650, 0, 0.0, 2.7246153846153813, 1, 39, 2.0, 3.0, 5.0, 21.0, 1.0929035252023553, 0.3607435464046837, 0.1910446591906461], "isController": false}, {"data": ["GET /api/student/timesheet", 1148, 0, 0.0, 7.04703832752613, 4, 55, 6.0, 9.100000000000136, 14.0, 34.0, 1.9608512964164928, 0.6625532700782291, 1.103172345249889], "isController": false}, {"data": ["GET /api/student/badges", 1149, 0, 0.0, 10.043516100957351, 6, 63, 8.0, 14.0, 20.0, 33.5, 1.9575106053120261, 53.516122456748214, 1.0955578143900029], "isController": false}, {"data": ["GET /api/student/profile", 1142, 0, 0.0, 6.815236427320482, 3, 53, 5.0, 9.0, 14.0, 34.569999999999936, 1.962111658242072, 2.458387946801346, 1.1000485131892734], "isController": false}, {"data": ["GET /api/student/programme", 1164, 0, 0.0, 6.051546391752582, 3, 60, 5.0, 8.0, 12.0, 30.699999999999818, 1.9634236440738004, 4.2010363321930635, 1.1046185287353123], "isController": false}, {"data": ["GET /api/student/dashboard", 1166, 0, 0.0, 6.091766723842193, 3, 33, 5.0, 9.0, 12.649999999999864, 23.0, 1.962160261037993, 0.7051513438105286, 1.1039090647681167], "isController": false}, {"data": ["GET /api/register/hierarchy", 649, 0, 0.0, 8.338983050847467, 4, 58, 7.0, 12.0, 17.0, 29.5, 1.0915414785761859, 1.5722887508787833, 0.1940044424813143], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 13533, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
