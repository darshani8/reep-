/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /api/auth/me"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/ledger"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/placement-readiness"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/auth/login"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/leaderboards"], "isController": false}, {"data": [1.0, 500, 1500, "GET /health"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/auth/sso/status"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/timesheet"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/badges"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/profile"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/programme"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/dashboard"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/register/hierarchy"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 17529, 0, 0.0, 9.888527582862764, 1, 357, 6.0, 19.0, 23.0, 39.0, 586.4503178320508, 562.1791294642857, 119.5382744542489], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /api/auth/me", 146, 0, 0.0, 23.150684931506852, 12, 73, 22.0, 28.600000000000023, 38.30000000000001, 70.18, 5.090478016805551, 10.056676785153934, 2.8136821850702556], "isController": false}, {"data": ["GET /api/student/ledger", 145, 0, 0.0, 15.11724137931034, 6, 30, 15.0, 19.400000000000006, 21.0, 29.539999999999992, 5.102399887395313, 19.881421436237595, 2.85515149948976], "isController": false}, {"data": ["GET /api/student/jobs", 145, 0, 0.0, 31.620689655172416, 14, 97, 29.0, 41.20000000000002, 47.69999999999999, 91.93999999999991, 5.09576524336672, 6.091031892461782, 2.8414862831664034], "isController": false}, {"data": ["GET /api/student/placement-readiness", 145, 0, 0.0, 27.77931034482757, 9, 357, 24.0, 32.400000000000006, 38.39999999999998, 229.1199999999978, 5.104016332852265, 7.067866367172376, 2.9208530967299096], "isController": false}, {"data": ["POST /api/auth/login", 1, 0, 0.0, 196.0, 196, 196, 196.0, 196.0, 196.0, 196.0, 5.1020408163265305, 4.828005420918367, 1.2854751275510203], "isController": false}, {"data": ["GET /api/student/leaderboards", 145, 0, 0.0, 18.034482758620687, 7, 75, 16.0, 23.0, 25.69999999999999, 69.93999999999991, 5.099887450759708, 1.937359588228053, 2.883627767568233], "isController": false}, {"data": ["GET /health", 5360, 0, 0.0, 4.623507462686572, 1, 321, 4.0, 6.0, 8.0, 20.0, 179.35419106575205, 49.39246277396687, 29.074995817299648], "isController": false}, {"data": ["GET /api/auth/sso/status", 5359, 0, 0.0, 5.264228400821033, 1, 75, 5.0, 7.0, 9.0, 19.399999999999636, 179.72365685156615, 59.32284767170836, 31.416537672295256], "isController": false}, {"data": ["GET /api/student/timesheet", 145, 0, 0.0, 14.931034482758621, 7, 38, 14.0, 19.0, 22.69999999999999, 36.619999999999976, 5.105274276459404, 1.7250243160692909, 2.871716780508415], "isController": false}, {"data": ["GET /api/student/badges", 145, 0, 0.0, 20.524137931034478, 9, 44, 20.0, 27.0, 30.69999999999999, 40.779999999999944, 5.101861299743148, 139.47910848272406, 2.8548501218289295], "isController": false}, {"data": ["GET /api/student/profile", 145, 0, 0.0, 14.868965517241376, 7, 51, 14.0, 19.400000000000006, 22.399999999999977, 41.79999999999984, 5.166761687571265, 6.473589106595639, 2.8962121178377993], "isController": false}, {"data": ["GET /api/student/programme", 145, 0, 0.0, 14.565517241379313, 5, 79, 13.0, 17.0, 23.099999999999966, 77.15999999999997, 5.095944331201237, 10.90352932584171, 2.8664686863006956], "isController": false}, {"data": ["GET /api/student/dashboard", 145, 0, 0.0, 14.81379310344827, 4, 38, 14.0, 20.0, 21.69999999999999, 34.319999999999936, 5.093080435546189, 1.8303257815244118, 2.8648577449947314], "isController": false}, {"data": ["GET /api/register/hierarchy", 5358, 0, 0.0, 17.13139231056364, 4, 351, 16.0, 22.0, 25.0, 54.409999999999854, 179.7202562640459, 258.87439256783955, 31.942467421930033], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 17529, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
