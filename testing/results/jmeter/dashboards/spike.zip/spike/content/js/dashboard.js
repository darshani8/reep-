/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.96137173269238, "KoPercent": 0.03862826730760977};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9909867376282244, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9906500445235975, 500, 1500, "GET /api/auth/me"], "isController": false}, {"data": [0.9970278920896205, 500, 1500, "GET /api/student/ledger"], "isController": false}, {"data": [0.9925339366515837, 500, 1500, "GET /api/student/jobs"], "isController": false}, {"data": [0.9958294717330862, 500, 1500, "GET /api/student/placement-readiness"], "isController": false}, {"data": [0.04, 500, 1500, "POST /api/auth/login"], "isController": false}, {"data": [0.9922621756941283, 500, 1500, "GET /api/student/leaderboards"], "isController": false}, {"data": [0.9903381642512077, 500, 1500, "GET /health"], "isController": false}, {"data": [0.9951338199513382, 500, 1500, "GET /api/auth/sso/status"], "isController": false}, {"data": [0.9972337482710927, 500, 1500, "GET /api/student/timesheet"], "isController": false}, {"data": [0.9965564738292011, 500, 1500, "GET /api/student/badges"], "isController": false}, {"data": [0.9967472118959108, 500, 1500, "GET /api/student/profile"], "isController": false}, {"data": [0.996859578286227, 500, 1500, "GET /api/student/programme"], "isController": false}, {"data": [0.996203662349263, 500, 1500, "GET /api/student/dashboard"], "isController": false}, {"data": [0.9951100244498777, 500, 1500, "GET /api/register/hierarchy"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 23299, 9, 0.03862826730760977, 100.03532340443844, 1, 2477, 69.0, 178.0, 220.0, 487.9800000000032, 260.1757657647598, 985.6450732334089, 140.373648378438], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /api/auth/me", 2246, 2, 0.08904719501335707, 106.53472840605521, 5, 1648, 86.0, 199.0, 237.6500000000001, 700.8300000000022, 25.397184372703116, 42.95496869169446, 14.038647735625036], "isController": false}, {"data": ["GET /api/student/ledger", 2187, 1, 0.04572473708276177, 81.79286694101505, 4, 1002, 67.0, 163.20000000000005, 193.5999999999999, 296.1199999999999, 25.777023443301157, 100.43976908083165, 14.424816738711502], "isController": false}, {"data": ["GET /api/student/jobs", 2210, 1, 0.04524886877828054, 137.12895927601798, 8, 1008, 118.0, 257.0, 305.0, 637.9799999999896, 25.800877930325957, 30.84011190109274, 14.387765451340243], "isController": false}, {"data": ["GET /api/student/placement-readiness", 2158, 0, 0.0, 115.30074142724762, 6, 827, 103.0, 223.0, 259.09999999999945, 473.4599999999991, 25.73735494412442, 35.64020440504729, 14.729372212184098], "isController": false}, {"data": ["POST /api/auth/login", 100, 0, 0.0, 1883.9700000000003, 512, 2477, 1860.0, 2276.4, 2332.0, 2475.9699999999993, 34.118048447628794, 32.286535632036845, 8.596148925281474], "isController": false}, {"data": ["GET /api/student/leaderboards", 2197, 1, 0.04551661356395084, 97.04733727810655, 4, 1018, 77.0, 183.0, 223.0999999999999, 788.1599999999999, 25.733528550512446, 9.775725201317716, 14.551255948023426], "isController": false}, {"data": ["GET /health", 414, 2, 0.4830917874396135, 41.83574879227055, 1, 1293, 20.0, 71.5, 117.25, 712.3000000000045, 4.624768203042963, 1.2736178059161285, 0.7497182829151678], "isController": false}, {"data": ["GET /api/auth/sso/status", 411, 1, 0.24330900243309003, 48.7566909975669, 1, 1349, 28.0, 102.0, 141.0, 407.87999999999965, 4.61891169000472, 1.5246017101773393, 0.807407414561372], "isController": false}, {"data": ["GET /api/student/timesheet", 2169, 0, 0.0, 80.49884739511296, 3, 675, 67.0, 166.0, 195.5, 361.5000000000009, 25.788885454069863, 8.713822624129076, 14.507014399983355], "isController": false}, {"data": ["GET /api/student/badges", 2178, 0, 0.0, 100.61386593204767, 5, 980, 86.0, 192.10000000000014, 230.09999999999945, 358.21000000000004, 25.800184794712028, 705.3478255155891, 14.437780967921531], "isController": false}, {"data": ["GET /api/student/profile", 2152, 0, 0.0, 80.36059479553896, 3, 775, 65.0, 163.70000000000005, 198.3499999999999, 376.3899999999926, 25.77091192144183, 32.28914062032214, 14.446564296299623], "isController": false}, {"data": ["GET /api/student/programme", 2229, 0, 0.0, 70.82817406908924, 3, 956, 54.0, 143.0, 178.0, 352.7999999999993, 25.917097843148657, 55.45347790462764, 14.57911694814255], "isController": false}, {"data": ["GET /api/student/dashboard", 2239, 0, 0.0, 71.68691380080391, 3, 832, 58.0, 137.0, 171.0, 349.9999999999991, 25.880503508143285, 9.300805948238992, 14.558539522239432], "isController": false}, {"data": ["GET /api/register/hierarchy", 409, 1, 0.24449877750611246, 89.64303178484109, 4, 1671, 74.0, 166.0, 192.5, 441.0, 4.632723565724642, 6.673112558050632, 0.8233942275018407], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 1,648 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,008 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,002 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,349 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,671 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,018 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,154 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,130 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}, {"data": ["The operation lasted too long: It took 1,293 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 11.11111111111111, 0.00429202970084553], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 23299, 9, "The operation lasted too long: It took 1,648 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,008 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,002 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,349 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,671 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET /api/auth/me", 2246, 2, "The operation lasted too long: It took 1,648 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,130 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["GET /api/student/ledger", 2187, 1, "The operation lasted too long: It took 1,002 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GET /api/student/jobs", 2210, 1, "The operation lasted too long: It took 1,008 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /api/student/leaderboards", 2197, 1, "The operation lasted too long: It took 1,018 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["GET /health", 414, 2, "The operation lasted too long: It took 1,154 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,293 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", ""], "isController": false}, {"data": ["GET /api/auth/sso/status", 411, 1, "The operation lasted too long: It took 1,349 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /api/register/hierarchy", 409, 1, "The operation lasted too long: It took 1,671 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
