/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 100.0, "KoPercent": 0.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [1.0, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "GET /api/auth/me"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/ledger"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/jobs"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/placement-readiness"], "isController": false}, {"data": [1.0, 500, 1500, "POST /api/auth/login"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/leaderboards"], "isController": false}, {"data": [1.0, 500, 1500, "GET /health"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/auth/sso/status"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/timesheet"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/badges"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/profile"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/programme"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/student/dashboard"], "isController": false}, {"data": [1.0, 500, 1500, "GET /api/register/hierarchy"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 11947, 0, 0.0, 8.754582740436971, 0, 165, 7.0, 15.0, 21.0, 46.0, 66.63877733154841, 243.0281673569277, 34.890555058776776], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /api/auth/me", 1099, 0, 0.0, 10.837124658780711, 5, 165, 8.0, 17.0, 22.0, 70.0, 6.195877683564857, 9.812207938573989, 3.424674579001669], "isController": false}, {"data": ["GET /api/student/ledger", 1073, 0, 0.0, 7.725069897483698, 3, 71, 6.0, 12.0, 18.0, 36.0, 6.148856186677669, 23.95892205551162, 3.440717377896782], "isController": false}, {"data": ["GET /api/student/jobs", 1083, 0, 0.0, 13.24930747922436, 7, 117, 10.0, 21.0, 28.0, 53.16000000000008, 6.16083009079118, 7.364117217898833, 3.4353847478923476], "isController": false}, {"data": ["GET /api/student/placement-readiness", 1062, 0, 0.0, 11.199623352165718, 5, 149, 8.0, 18.0, 25.0, 50.73999999999978, 6.1658151416627955, 8.538208858279145, 3.528484055678123], "isController": false}, {"data": ["POST /api/auth/login", 50, 0, 0.0, 51.16, 39, 101, 44.5, 77.9, 90.79999999999998, 101.0, 1.7319016279875303, 1.6388795678905437, 0.4363580273640457], "isController": false}, {"data": ["GET /api/student/leaderboards", 1081, 0, 0.0, 7.72802960222017, 4, 65, 6.0, 12.0, 16.0, 37.54000000000019, 6.1642859179425775, 2.3417062715621704, 3.4854702602429217], "isController": false}, {"data": ["GET /health", 375, 0, 0.0, 2.4400000000000004, 0, 66, 2.0, 4.0, 7.0, 23.480000000000018, 2.0937205134361023, 0.5765910007704892, 0.33941172385780566], "isController": false}, {"data": ["GET /api/auth/sso/status", 374, 0, 0.0, 2.7272727272727284, 1, 51, 2.0, 4.0, 6.0, 26.5, 2.1017493972924526, 0.6937415002781727, 0.36739564659702045], "isController": false}, {"data": ["GET /api/student/timesheet", 1066, 0, 0.0, 7.36210131332082, 3, 89, 5.0, 12.0, 17.0, 33.649999999999636, 6.15519640619677, 2.0797831606875805, 3.4622979784856827], "isController": false}, {"data": ["GET /api/student/badges", 1070, 0, 0.0, 10.883177570093466, 5, 135, 8.0, 17.0, 25.0, 50.289999999999964, 6.147588077126376, 168.0680939640165, 3.4400077814388803], "isController": false}, {"data": ["GET /api/student/profile", 1054, 0, 0.0, 7.46584440227705, 3, 77, 5.0, 12.0, 19.0, 49.25000000000023, 6.14932234934452, 7.704668529500994, 3.4469834262927286], "isController": false}, {"data": ["GET /api/student/programme", 1091, 0, 0.0, 6.325389550870759, 3, 60, 5.0, 11.0, 16.0, 29.0, 6.180602764559256, 13.224317047997394, 3.476589055064582], "isController": false}, {"data": ["GET /api/student/dashboard", 1096, 0, 0.0, 7.009124087591239, 3, 81, 5.0, 12.0, 18.0, 43.059999999999945, 6.184054618292614, 2.2223946284489084, 3.478530722789596], "isController": false}, {"data": ["GET /api/register/hierarchy", 373, 0, 0.0, 9.000000000000007, 4, 74, 7.0, 15.600000000000023, 21.30000000000001, 53.039999999999964, 2.100591882592119, 3.025754909007203, 0.3733473853825837], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": []}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 11947, 0, "", "", "", "", "", "", "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
