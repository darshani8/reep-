/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 99.95612110574814, "KoPercent": 0.04387889425186485};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9721464410401206, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9683597002497918, 500, 1500, "GET /api/auth/me"], "isController": false}, {"data": [0.9864010120177104, 500, 1500, "GET /api/student/ledger"], "isController": false}, {"data": [0.8921979865771812, 500, 1500, "GET /api/student/jobs"], "isController": false}, {"data": [0.9364002543989824, 500, 1500, "GET /api/student/placement-readiness"], "isController": false}, {"data": [0.9, 500, 1500, "POST /api/auth/login"], "isController": false}, {"data": [0.9867480016827934, 500, 1500, "GET /api/student/leaderboards"], "isController": false}, {"data": [0.9987492182614134, 500, 1500, "GET /health"], "isController": false}, {"data": [0.9971839799749687, 500, 1500, "GET /api/auth/sso/status"], "isController": false}, {"data": [0.9894202285230639, 500, 1500, "GET /api/student/timesheet"], "isController": false}, {"data": [0.9731727925644276, 500, 1500, "GET /api/student/badges"], "isController": false}, {"data": [0.9898110804500106, 500, 1500, "GET /api/student/profile"], "isController": false}, {"data": [0.9899539556299707, 500, 1500, "GET /api/student/programme"], "isController": false}, {"data": [0.9871553884711779, 500, 1500, "GET /api/student/dashboard"], "isController": false}, {"data": [0.9902943018159048, 500, 1500, "GET /api/register/hierarchy"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 52417, 23, 0.04387889425186485, 301.9473262491198, 1, 1134, 350.0, 480.0, 529.0, 718.9800000000032, 290.8161849967543, 1068.111031289357, 152.7584779285096], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["GET /api/auth/me", 4804, 4, 0.08326394671107411, 343.13259783513786, 11, 1060, 364.0, 476.0, 514.0, 713.8499999999995, 26.72377826606959, 43.22789909743276, 14.771846229800017], "isController": false}, {"data": ["GET /api/student/ledger", 4743, 0, 0.0, 288.1861690912921, 6, 936, 303.0, 408.0, 451.8000000000002, 664.1200000000008, 26.41030352638525, 102.90733502956752, 14.779106955673788], "isController": false}, {"data": ["GET /api/student/jobs", 4768, 7, 0.14681208053691275, 396.36199664429455, 14, 1134, 420.0, 549.0, 596.0, 782.3100000000004, 26.529419947141463, 31.710947280567535, 14.793945176658784], "isController": false}, {"data": ["GET /api/student/placement-readiness", 4717, 10, 0.21199915200339198, 374.0394318422714, 12, 1134, 395.0, 515.1999999999998, 571.0999999999995, 805.5599999999977, 26.27196524548163, 36.38051437313766, 15.035227937285919], "isController": false}, {"data": ["POST /api/auth/login", 100, 0, 0.0, 359.87000000000006, 76, 929, 381.0, 567.8, 617.6499999999999, 928.7199999999998, 1.6871941960519656, 1.5966063670490973, 0.42509385017715534], "isController": false}, {"data": ["GET /api/student/leaderboards", 4754, 0, 0.0, 300.28880942364526, 7, 962, 317.0, 427.0, 464.0, 624.1499999999987, 26.46109317599911, 10.0521144975231, 14.96257253283981], "isController": false}, {"data": ["GET /health", 1599, 0, 0.0, 109.60975609756098, 1, 700, 125.0, 187.0, 206.0, 256.0, 8.883037232092263, 2.4463051752441585, 1.4400236137962068], "isController": false}, {"data": ["GET /api/auth/sso/status", 1598, 0, 0.0, 138.40488110137667, 1, 765, 159.0, 232.0, 251.0, 317.27999999999975, 8.870238075413676, 2.927871552236155, 1.550559194823289], "isController": false}, {"data": ["GET /api/student/timesheet", 4726, 1, 0.021159542953872196, 285.36542530681254, 4, 1013, 302.0, 404.0, 443.64999999999964, 604.3799999999974, 26.320186235088386, 8.89334417709041, 14.805790033721696], "isController": false}, {"data": ["GET /api/student/badges", 4734, 0, 0.0, 330.7801013941707, 10, 991, 349.0, 462.0, 506.0, 698.2499999999982, 26.35784081734918, 720.5935094547758, 14.74975032014699], "isController": false}, {"data": ["GET /api/student/profile", 4711, 0, 0.0, 286.4924644449165, 5, 981, 302.0, 409.0, 447.0, 608.7600000000002, 26.256388534357356, 32.89740868123094, 14.718622333814505], "isController": false}, {"data": ["GET /api/student/programme", 4778, 0, 0.0, 269.0839263290087, 4, 969, 282.0, 387.0, 427.0, 652.0, 26.591570616815357, 56.89661252093988, 14.958448714318708], "isController": false}, {"data": ["GET /api/student/dashboard", 4788, 1, 0.020885547201336674, 285.1522556390983, 5, 1013, 300.0, 405.10000000000036, 449.5500000000002, 661.2199999999993, 26.65523557148981, 9.57922528350415, 14.994260458825789], "isController": false}, {"data": ["GET /api/register/hierarchy", 1597, 0, 0.0, 239.50782717595487, 4, 890, 269.0, 395.0, 437.0999999999999, 586.1399999999999, 8.868379257877143, 12.774276763055454, 1.5762158446617576], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["The operation lasted too long: It took 1,005 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,088 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,070 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,044 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,027 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,025 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,011 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 8.695652173913043, 0.0038155560219012914], "isController": false}, {"data": ["The operation lasted too long: It took 1,047 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,061 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,134 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 8.695652173913043, 0.0038155560219012914], "isController": false}, {"data": ["The operation lasted too long: It took 1,078 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,008 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,006 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,013 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 3, 13.043478260869565, 0.005723334032851937], "isController": false}, {"data": ["The operation lasted too long: It took 1,128 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,060 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, 4.3478260869565215, 0.0019077780109506457], "isController": false}, {"data": ["The operation lasted too long: It took 1,102 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, 8.695652173913043, 0.0038155560219012914], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 52417, 23, "The operation lasted too long: It took 1,013 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 3, "The operation lasted too long: It took 1,011 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,134 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,102 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,005 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["GET /api/auth/me", 4804, 4, "The operation lasted too long: It took 1,044 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,025 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,006 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,060 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /api/student/jobs", 4768, 7, "The operation lasted too long: It took 1,088 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,134 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,038 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,027 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,011 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": ["GET /api/student/placement-readiness", 4717, 10, "The operation lasted too long: It took 1,102 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 2, "The operation lasted too long: It took 1,005 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,070 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,134 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "The operation lasted too long: It took 1,078 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /api/student/timesheet", 4726, 1, "The operation lasted too long: It took 1,013 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["GET /api/student/dashboard", 4788, 1, "The operation lasted too long: It took 1,013 milliseconds, but should not have lasted longer than 1,000 milliseconds.", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
